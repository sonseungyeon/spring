package com.myapp.user;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/ajax")
public class UserAjaxController {
	private static final Logger logger = LoggerFactory.getLogger(UserAjaxController.class);
	
	@Autowired
	UserService userService;
	
	@GetMapping("/main")
	public String showMain() {
		return "ajax/main";
	}
			
	//ajax로는 화면을 보내는게 아니라 데이터만 보낸다
	@GetMapping("/list")
	//데이터만 찾으려면 @ResponseBody어노테이션 추가
	//->@ResponseBody에 List<User>를 반환하겟다 라는 의미
	// 메소드에서 리턴되는 값은 View 를 통해서 출력되지 않고 HTTP Response Body 에 직접 쓰여지게 됩니다.
	public @ResponseBody List<User> getUserList(){
		logger.info("/get list!!!!");
		return userService.getUserList();
	}
	
	@PostMapping("/add")
	@ResponseBody
	public boolean addUser(User user) {
		
		return userService.addUser(user);
	}
}
